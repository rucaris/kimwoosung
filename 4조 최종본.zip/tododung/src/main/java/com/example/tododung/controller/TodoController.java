package com.example.tododung.controller;

import com.example.tododung.entity.Todo;
import com.example.tododung.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
@CrossOrigin(origins = "http://localhost:5500")
public class TodoController {

    @Autowired
    private TodoService todoService;

    // 1. 모든 할 일 조회 (GET)
    @GetMapping
    public List<Todo> getAllTodos() {
        return todoService.getAllTodos();
    }

    // 2. 할 일 추가 (POST)
    @PostMapping
    public Todo addTodo(@RequestBody Todo todo) {
        return todoService.addTodo(todo);
    }

    // 3. 특정 할 일 수정 (PUT)
    @PutMapping("/{id}")
    public Todo updateTodo(@PathVariable Long id, @RequestBody Todo todo) {
        return todoService.updateTodo(id, todo);
    }

    // 4. 특정 할 일 삭제 (DELETE)
    @DeleteMapping("/{id}")
    public void deleteTodo(@PathVariable Long id) {
        todoService.deleteTodo(id);
    }

    // ✅ **5. 특정 할 일 완료 처리 (PATCH, 정확히 수정됨)**
    @PatchMapping("/{id}/complete") // 여기 수정했어!
    public Todo toggleComplete(@PathVariable Long id, @RequestBody Todo updatedTodo) {
        return todoService.toggleComplete(id, updatedTodo.isCompleted());
    }
}
