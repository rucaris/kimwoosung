package com.example.tododung.service;

import com.example.tododung.entity.Todo;
import com.example.tododung.repository.TodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TodoService {

    @Autowired
    private TodoRepository todoRepository;

    // 1. 모든 할 일 조회
    public List<Todo> getAllTodos() {
        return todoRepository.findAll();
    }

    // 2. 새로운 할 일 추가
    public Todo addTodo(Todo todo) {
        return todoRepository.save(todo);
    }

    // 3. 할 일 수정
    public Todo updateTodo(Long id, Todo newTodo) {
        Optional<Todo> existingTodo = todoRepository.findById(id);
        if (existingTodo.isPresent()) {
            Todo todo = existingTodo.get();
            todo.setTask(newTodo.getTask());
            todo.setCompleted(newTodo.isCompleted());
            return todoRepository.save(todo);
        }
        return null;
    }

    // 4. 할 일 삭제
    public void deleteTodo(Long id) {
        todoRepository.deleteById(id);
    }

    // ✅ 5. 할 일 완료 상태 토글 (새로 추가됨)
    public Todo toggleComplete(Long id, boolean completed) {
        Todo todo = todoRepository.findById(id).orElseThrow();
        todo.setCompleted(completed);
        return todoRepository.save(todo);
    }
}
