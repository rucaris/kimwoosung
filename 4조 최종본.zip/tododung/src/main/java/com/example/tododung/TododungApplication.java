package com.example.tododung;  // 수정됨

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication  // 패키지 스캔이 정상적으로 작동하게 됨
public class TododungApplication {
    public static void main(String[] args) {
        SpringApplication.run(TododungApplication.class, args);
    }
}
