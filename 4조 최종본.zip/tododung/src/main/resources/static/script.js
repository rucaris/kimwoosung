const API_URL = "http://localhost:8080/api/todos";

const input = document.querySelector('#todo-input');
const submitBtn = document.querySelector('#submit');
const todoListContainer = document.querySelector('.todo-lists');

// 서버에서 할 일 목록 불러오기
async function fetchTodos() {
    const response = await fetch(API_URL);
    const todos = await response.json();
    renderTodos(todos);
}

// 할 일 목록 렌더링 (삭제, 수정, 완료 버튼 포함)
function renderTodos(todos) {
    todoListContainer.innerHTML = "";
    todos.forEach(todo => {
        const todoItem = document.createElement('div');
        todoItem.classList.add('todo-item');

        const todoText = document.createElement('input');
        todoText.type = 'text';
        todoText.value = todo.task;
        todoText.readOnly = true;

        if (todo.completed) {
            todoText.classList.add('done');
        }

        const actions = document.createElement('div');
        actions.classList.add('todo-actions');

        // ✅ 완료 버튼 (체크 아이콘, 토글 기능 추가)
        const completeBtn = document.createElement('button');
        completeBtn.innerHTML = '<i class="fa-solid fa-check"></i>';
        completeBtn.classList.add('action-btn', 'complete-btn');
        completeBtn.addEventListener('click', async () => {
            await fetch(`${API_URL}/${todo.id}/complete`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ completed: !todo.completed }) // ✅ 상태 토글
            });
            fetchTodos();
        });

        // ✅ 수정 버튼 (연필 아이콘)
        const editBtn = document.createElement('button');
        editBtn.innerHTML = '<i class="fa-solid fa-edit"></i>';
        editBtn.classList.add('action-btn', 'edit-btn');
        editBtn.addEventListener('click', () => {
            if (editBtn.innerHTML.includes("fa-edit")) {
                editBtn.innerHTML = '<i class="fa-solid fa-save"></i>';
                todoText.readOnly = false;
                todoText.focus();
            } else {
                editBtn.innerHTML = '<i class="fa-solid fa-edit"></i>';
                todoText.readOnly = true;

                fetch(`${API_URL}/${todo.id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ task: todoText.value, completed: todo.completed })
                }).then(fetchTodos);
            }
        });

        // ✅ 삭제 버튼 (휴지통 아이콘)
        const deleteBtn = document.createElement('button');
        deleteBtn.innerHTML = '<i class="fa-solid fa-trash"></i>';
        deleteBtn.classList.add('action-btn', 'delete-btn');
        deleteBtn.addEventListener('click', async () => {
            await fetch(`${API_URL}/${todo.id}`, { method: "DELETE" });
            fetchTodos();
        });

        // 🎯 **버튼을 추가해야 하는 부분**
        actions.appendChild(completeBtn);
        actions.appendChild(editBtn);
        actions.appendChild(deleteBtn);
        todoItem.appendChild(todoText);
        todoItem.appendChild(actions);
        todoListContainer.appendChild(todoItem);
    });
}

// 할 일 추가 기능
submitBtn.addEventListener('click', async () => {
    const task = input.value.trim();
    if (!task) return;
    
    await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task })
    });

    input.value = "";
    fetchTodos();
});

// 초기 데이터 로딩
fetchTodos();
